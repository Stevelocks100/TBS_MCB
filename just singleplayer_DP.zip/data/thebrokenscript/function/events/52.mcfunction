# Created by Stevelocks
execute at @n[tag=tbs.base_found,sort=random] positioned ~5.029468590354211 ~-5.961018283861752 ~-1.0536253329522793 run place template lavacast
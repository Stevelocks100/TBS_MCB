# Created by Stevelocks
execute as @a at @s rotated as @s run playsound minecraft:block.grass.break neutral @s ^0.8863372824368092 ^0.8303242692390045 ^1.1264367362145666 555.0 0.8 0.0
schedule function thebrokenscript:events/zzz/20 20t append
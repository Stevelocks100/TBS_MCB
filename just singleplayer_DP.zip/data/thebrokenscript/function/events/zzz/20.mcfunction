# Created by Stevelocks
execute as @a at @s rotated as @s run playsound minecraft:block.grass.break neutral @s ^-1.1765499018847025 ^-2.2553923937793674 ^2.6118193822652565 555.0 0.8 0.0
schedule function thebrokenscript:events/zzz/19 20t append
# Created by Stevelocks
execute as @a at @s rotated as @s run playsound minecraft:block.grass.break neutral @s ^3.7926307569219695 ^0.040101825650175726 ^-2.317269869452663 555.0 0.8 0.0
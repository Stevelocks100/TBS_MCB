# Created by Stevelocks
execute as @a at @s rotated as @s run playsound minecraft:block.grass.break neutral @s ^-1.8764128749693532 ^-3.8605146854830275 ^2.2427939424130745 555.0 0.8 0.0
schedule function thebrokenscript:events/zzz/18 20t append
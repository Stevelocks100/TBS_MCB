# Created by Stevelocks
function thebrokenscript:night_lib/main
function thebrokenscript:overlay_lib/as_player
execute as @e[tag=tbs.entity] at @s rotated as @s run function thebrokenscript:entity/entity_tick
function thebrokenscript:entity/player
execute as @e[tag=tbs.block] at @s run function thebrokenscript:blocks/tick/tick
scoreboard players remove @e[tag=tbs.particles] tbs.particle_decay 1
kill @e[tag=tbs.particles,scores={tbs.particle_decay=..0}]
scoreboard objectives add tbs.replace_temp dummy
execute as @e[type=#thebrokenscript:despawnable,tag=!tbs.entity.replace_checked,limit=30,nbt={PersistenceRequired:0b}] at @s run function thebrokenscript:zzz/0
scoreboard objectives remove tbs.replace_temp
function thebrokenscript:entity_check
function thebrokenscript:base_detect/tick
execute as @a at @s if block ~ ~ ~ #minecraft:beds if predicate thebrokenscript:sleep_condition run function thebrokenscript:zzz/2
execute at @a run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 stone replace deepslate
execute as @e[type=villager,tag=!tbs.entity.testificate_check] at @s run function thebrokenscript:zzz/3
scoreboard players remove @e[tag=tbs.sound] tbs.sound_loop 1
kill @e[tag=tbs.sound,scores={tbs.sound_loop=..0}]
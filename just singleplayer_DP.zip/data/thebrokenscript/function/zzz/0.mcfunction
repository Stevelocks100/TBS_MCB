# Created by Stevelocks
tag @s add tbs.entity.replace_checked
execute store result score @s tbs.replace_temp run random value 1..400
execute if predicate {"condition":"minecraft:location_check","predicate":{"light":{"light":{"min":0,"max":5}},"can_see_sky":false}} if score @s tbs.replace_temp matches 24 run function thebrokenscript:entity/circuit/circuit_stalk_summon
execute if predicate {"condition":"minecraft:location_check","predicate":{"light":{"light":{"min":0,"max":5}},"can_see_sky":false}} if score @s tbs.replace_temp matches 25 run function thebrokenscript:entity/circuit/circuit_mineshaft_walk_summon
execute if predicate {"condition":"minecraft:location_check","predicate":{"light":{"light":{"min":0,"max":5}},"can_see_sky":false}} if score @s tbs.replace_temp matches 26 run function thebrokenscript:entity/circuit/circuit_disguised_as_creeper_summon
execute if score @s tbs.replace_temp matches 1..10 run function thebrokenscript:zzz/1